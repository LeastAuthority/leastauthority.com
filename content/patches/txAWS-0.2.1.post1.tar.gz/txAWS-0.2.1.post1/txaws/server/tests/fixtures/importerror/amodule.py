from txaws.server.method import Method
from txaws.server.tests.fixtures import method 

@method
class TestMethod(Method):
    pass
