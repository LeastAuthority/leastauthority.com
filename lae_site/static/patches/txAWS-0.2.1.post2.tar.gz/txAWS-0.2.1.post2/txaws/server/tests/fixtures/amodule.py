from txaws.server.tests.fixtures import method
from txaws.server.method import Method

@method
class TestMethod(Method):
    pass
