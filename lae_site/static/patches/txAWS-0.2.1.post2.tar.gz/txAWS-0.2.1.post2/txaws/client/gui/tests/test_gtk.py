# Copyright (C) 2009 Robert Collins <robertc@robertcollins.net>
# Licenced under the txaws licence available at /LICENSE in the txaws source.

from twisted.trial.unittest import TestCase


class UITests(TestCase):

    pass
    # Really need some, but UI testing hurts my brain.

